#pragma once
#include "common.h"

#include "Menu.h"
#include "Monster.h"
#include "Player.h"

int kl;
int i = 0;

void init()
{
	printf("�޴��� ESC�Դϴ�.\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printf("\t\t  #######      ##        ##       ######         ########     ########       ######\n"		);
	printf("\t\t  ##     ##    ##        ##      ##              ##     ##    ##     ##     ##    ##\n"		);
	printf("\t\t  ##     ##    ##        ##     ##               ##     ##    ##     ##    ##\n"			);
	printf("\t\t  #######      ##        ##    ##     #####      ########     ########    ##     #####\n"	);
	printf("\t\t  ##     ##    ##        ##     ##      ##       ##   ##      ##           ##      ##\n"	);
	printf("\t\t  ##     ##     ##      ##       ##    ##        ##    ##     ##            ##    ##\n"		);
	printf("\t\t  #######         ######          ######         ##     ##    ##             ######\n"		);
	printf("\n");
	printf("\n");
	printf("\t\t\t\t\t�÷��� �Ͻ÷��� ENTERŰ�� �����ּ���.\n");
	printf("\t\t\t\t\t      �����÷��� X�� �����ּ���.");
}